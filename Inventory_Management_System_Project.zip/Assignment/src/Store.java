package src;
import java.io.*;
import java.util.*;

public class Store {

    // Constants for file names
    private static final String ITEMS_FILE = "items.txt";
    private static final String TRANSACTIONS_FILE = "transactions.txt";

    public static void main(String[] args) throws IOException {
        Scanner input = new Scanner(System.in);

        // Main menu loop
        while (true) {
            // Display menu options
            System.out.println("\nI N V E N T O R Y    M A N A G E M E N T    S Y S T E M");
            System.out.println("-------------------------------------------------------");
            System.out.println("1. ADD NEW ITEM");
            System.out.println("2. UPDATE QUANTITY OF EXISTING ITEM");
            System.out.println("3. REMOVE ITEM");
            System.out.println("4. VIEW DAILY TRANSACTION REPORT");
            System.out.println("5. EXIT");
            System.out.print("\nEnter a choice and Press ENTER [1-5]: ");
            int choice = input.nextInt();

            // Perform actions based on user choice
            switch (choice) {
                case 1 -> addNewItem(input); // Add a new item
                case 2 -> updateQuantity(input); // Update item quantity
                case 3 -> removeItem(input); // Remove an item
                case 4 -> viewTransactionReport(); // View transaction report
                case 5 -> {
                    // Exit the program
                    System.out.println("Exiting... Thanks for using the program!");
                    return;
                }
                default -> System.out.println("Invalid choice! Please try again.");
            }
        }
    }

    // Method to add a new item to the inventory
    private static void addNewItem(Scanner input) throws IOException {
        System.out.print("Enter item description: ");
        input.nextLine(); // Clear buffer
        String description = input.nextLine();
        System.out.print("Enter unit price: ");
        double unitPrice = input.nextDouble();
        System.out.print("Enter quantity in stock: ");
        int qtyInStock = input.nextInt();

        // Generate a new unique ID for the item
        int newId = generateNewId();
        double totalPrice = unitPrice * qtyInStock;

        // Append the new item to the items file
        try (FileWriter writer = new FileWriter(ITEMS_FILE, true)) {
            writer.write(String.format("%05d,%s,%.2f,%d,%.2f%n", newId, description, unitPrice, qtyInStock, totalPrice));
        }

        // Log the transaction
        logTransaction(newId, description, qtyInStock, totalPrice, "ADD");
        System.out.println("New item added successfully.");
    }

    // Method to update the quantity of an existing item
    private static void updateQuantity(Scanner input) throws IOException {
        System.out.print("Enter item ID to update: ");
        String itemId = input.next();
        System.out.print("Enter new quantity: ");
        int newQty = input.nextInt();

        List<String> lines = new ArrayList<>(); // List to store updated lines
        boolean itemFound = false;

        // Read the items file and update the quantity for the specified item
        try (BufferedReader reader = new BufferedReader(new FileReader(ITEMS_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts[0].equals(itemId)) {
                    double unitPrice = Double.parseDouble(parts[2]);
                    double totalPrice = unitPrice * newQty;
                    lines.add(String.format("%s,%s,%.2f,%d,%.2f", parts[0], parts[1], unitPrice, newQty, totalPrice));
                    itemFound = true;
                } else {
                    lines.add(line);
                }
            }
        }

        if (itemFound) {
            // Write the updated data back to the items file
            try (FileWriter writer = new FileWriter(ITEMS_FILE)) {
                for (String line : lines) {
                    writer.write(line + System.lineSeparator());
                }
            }
            // Log the transaction
            logTransaction(Integer.parseInt(itemId), "Quantity Updated", newQty, 0, "UPDATE");
            System.out.println("Item quantity updated successfully.");
        } else {
            System.out.println("Item not found!");
        }
    }

    // Method to remove an item from the inventory
    private static void removeItem(Scanner input) throws IOException {
        System.out.print("Enter item ID to remove: ");
        String itemId = input.next();

        List<String> lines = new ArrayList<>(); // List to store remaining items
        boolean itemFound = false;

        // Read the items file and exclude the item to be removed
        try (BufferedReader reader = new BufferedReader(new FileReader(ITEMS_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts[0].equals(itemId)) {
                    itemFound = true;
                } else {
                    lines.add(line);
                }
            }
        }

        if (itemFound) {
            // Write the remaining items back to the items file
            try (FileWriter writer = new FileWriter(ITEMS_FILE)) {
                for (String line : lines) {
                    writer.write(line + System.lineSeparator());
                }
            }
            // Log the transaction
            logTransaction(Integer.parseInt(itemId), "Item Removed", 0, 0, "REMOVE");
            System.out.println("Item removed successfully.");
        } else {
            System.out.println("Item not found!");
        }
    }

    // Method to view the daily transaction report
    private static void viewTransactionReport() throws IOException {
        System.out.println("\nDAILY TRANSACTION REPORT:");
        try (BufferedReader reader = new BufferedReader(new FileReader(TRANSACTIONS_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
        }
    }

    // Method to generate a new unique item ID
    private static int generateNewId() throws IOException {
        int maxId = 0;
        try (BufferedReader reader = new BufferedReader(new FileReader(ITEMS_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                int id = Integer.parseInt(parts[0]);
                if (id > maxId) {
                    maxId = id;
                }
            }
        }
        return maxId + 1;
    }

    // Method to log a transaction in the transactions file
    private static void logTransaction(int id, String description, int qty, double totalPrice, String action) throws IOException {
        try (FileWriter writer = new FileWriter(TRANSACTIONS_FILE, true)) {
            writer.write(String.format("%05d,%s,%d,%.2f,%s%n", id, description, qty, totalPrice, action));
        }
    }
}



