package inventorymanagement;
	import javax.swing.*;
	import java.awt.*;
	import java.awt.event.*;
	import java.io.*;
	import java.util.*;

	public class StoreGUIFileCheck {
	    // Constants for file paths
	    private static final String ITEMS_FILE = "items.txt";
	    private static final String TRANSACTIONS_FILE = "transactions.txt";

	    public static void main(String[] args) {
	        // Create the main window (JFrame) for the application
	        JFrame frame = new JFrame("Inventory Management System");
	        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Ensure the application exits when the window is closed
	        frame.setSize(500, 300); // Set window size
	        frame.setLayout(new FlowLayout()); // Use FlowLayout to arrange buttons in a flow

	        // Create buttons for various options
	        JButton addItemButton = new JButton("Add New Item");
	        JButton updateItemButton = new JButton("Update Item Quantity");
	        JButton removeItemButton = new JButton("Remove Item");
	        JButton viewTransactionsButton = new JButton("View Daily Transactions");

	        // Add buttons to the main window
	        frame.add(addItemButton);
	        frame.add(updateItemButton);
	        frame.add(removeItemButton);
	        frame.add(viewTransactionsButton);

	        // Set up action listeners for buttons to handle user actions
	        addItemButton.addActionListener(e -> openAddItemDialogue()); // Opens dialogue to add a new item
	        updateItemButton.addActionListener(e -> openUpdateQuantityDialogue()); // Opens dialogue to update item quantity
	        removeItemButton.addActionListener(e -> openRemoveItemDialogue()); // Opens dialogue to remove an item
	        viewTransactionsButton.addActionListener(e -> viewTransactionReport()); // Opens the report of daily transactions

	        // Display the main window
	        frame.setVisible(true);
	    }

	    // Method to open the dialogue for adding a new item
	    private static void openAddItemDialogue() {
	        JPanel panel = new JPanel(new GridLayout(4, 2)); // Create a panel with a grid layout
	        JTextField descriptionField = new JTextField();
	        JTextField priceField = new JTextField();
	        JTextField quantityField = new JTextField();

	        // Add labels and text fields to the panel
	        panel.add(new JLabel("Description:"));
	        panel.add(descriptionField);
	        panel.add(new JLabel("Unit Price:"));
	        panel.add(priceField);
	        panel.add(new JLabel("Quantity in Stock:"));
	        panel.add(quantityField);

	        // Show a confirmation dialogue where user can input data
	        int option = JOptionPane.showConfirmDialog(null, panel, "Enter Item Details", JOptionPane.OK_CANCEL_OPTION);

	        // If the user clicked OK, proceed to add the new item
	        if (option == JOptionPane.OK_OPTION) {
	            try {
	                String description = descriptionField.getText(); // Get description from input
	                double unitPrice = Double.parseDouble(priceField.getText()); // Get unit price and convert to double
	                int qtyInStock = Integer.parseInt(quantityField.getText()); // Get quantity and convert to int

	                // Call method to add the new item to the inventory
	                addNewItem(description, unitPrice, qtyInStock);
	            } catch (Exception e) {
	                JOptionPane.showMessageDialog(null, "Invalid input. Please enter valid data.");
	            }
	        }
	    }

	    // Method to add a new item to the inventory
	    private static void addNewItem(String description, double unitPrice, int qtyInStock) throws IOException {
	        int newId = generateNewId(); // Generate a new unique item ID
	        double totalPrice = unitPrice * qtyInStock; // Calculate the total price for the quantity

	        // Write the new item details to the items file
	        try (FileWriter writer = new FileWriter(ITEMS_FILE, true)) {
	            writer.write(String.format("%05d,%s,%.2f,%d,%.2f%n", newId, description, unitPrice, qtyInStock, totalPrice));
	        }

	        // Log the transaction in the transactions file
	        logTransaction(newId, description, qtyInStock, totalPrice, "ADD");
	        JOptionPane.showMessageDialog(null, "New item added successfully.");
	    }

	    // Method to open the dialogue for updating an item's quantity
	    private static void openUpdateQuantityDialogue() {
	        JPanel panel = new JPanel(new GridLayout(2, 2)); // Create a panel with a grid layout
	        JTextField itemIdField = new JTextField();
	        JTextField newQuantityField = new JTextField();

	        // Add labels and text fields to the panel
	        panel.add(new JLabel("Item ID:"));
	        panel.add(itemIdField);
	        panel.add(new JLabel("New Quantity:"));
	        panel.add(newQuantityField);

	        // Show a confirmation dialogue for the user to enter the item ID and new quantity
	        int option = JOptionPane.showConfirmDialog(null, panel, "Update Item Quantity", JOptionPane.OK_CANCEL_OPTION);

	        // If the user clicked OK, proceed to update the quantity
	        if (option == JOptionPane.OK_OPTION) {
	            try {
	                String itemId = itemIdField.getText(); // Get the item ID from input
	                int newQty = Integer.parseInt(newQuantityField.getText()); // Get the new quantity and convert to int
	                updateQuantity(itemId, newQty); // Call method to update the item's quantity
	            } catch (Exception e) {
	                JOptionPane.showMessageDialog(null, "Invalid input. Please enter valid data.");
	            }
	        }
	    }

	    // Method to update the quantity of an existing item
	    private static void updateQuantity(String itemId, int newQty) throws IOException {
	        List<String> lines = new ArrayList<>(); // List to hold all lines from the file
	        boolean itemFound = false;

	        // Read through the items file and update the quantity for the specified item
	        try (BufferedReader reader = new BufferedReader(new FileReader(ITEMS_FILE))) {
	            String line;
	            while ((line = reader.readLine()) != null) {
	                String[] parts = line.split(",");
	                if (parts[0].equals(itemId)) { // If the item ID matches, update the quantity
	                    double unitPrice = Double.parseDouble(parts[2]);
	                    double totalPrice = unitPrice * newQty;
	                    lines.add(String.format("%s,%s,%.2f,%d,%.2f", parts[0], parts[1], unitPrice, newQty, totalPrice));
	                    itemFound = true;
	                } else {
	                    lines.add(line); // Keep the rest of the items unchanged
	                }
	            }
	        }

	        // If the item was found, write the updated details back to the file
	        if (itemFound) {
	            try (FileWriter writer = new FileWriter(ITEMS_FILE)) {
	                for (String line : lines) {
	                    writer.write(line + System.lineSeparator());
	                }
	            }
	            logTransaction(Integer.parseInt(itemId), "Quantity Updated", newQty, 0, "UPDATE");
	            JOptionPane.showMessageDialog(null, "Item quantity updated successfully.");
	        } else {
	            JOptionPane.showMessageDialog(null, "Item not found!");
	        }
	    }

	    // Method to open the dialogue for removing an item
	    private static void openRemoveItemDialogue() {
	        String itemId = JOptionPane.showInputDialog("Enter Item ID to Remove:"); // Ask for the item ID

	        // If the user provides an item ID, proceed to remove it
	        if (itemId != null && !itemId.isEmpty()) {
	            try {
	                removeItem(itemId); // Call method to remove the item
	            } catch (IOException e) {
	                JOptionPane.showMessageDialog(null, "Error removing item.");
	            }
	        }
	    }

	    // Method to remove an item from the inventory
	    private static void removeItem(String itemId) throws IOException {
	        List<String> lines = new ArrayList<>(); // List to store items that remain after removal
	        boolean itemFound = false;

	        // Read through the items file and exclude the item to be removed
	        try (BufferedReader reader = new BufferedReader(new FileReader(ITEMS_FILE))) {
	            String line;
	            while ((line = reader.readLine()) != null) {
	                String[] parts = line.split(",");
	                if (parts[0].equals(itemId)) {
	                    itemFound = true; // Mark item as found
	                } else {
	                    lines.add(line); // Keep the other items
	                }
	            }
	        }

	        // If the item was found, write the remaining items back to the file
	        if (itemFound) {
	            try (FileWriter writer = new FileWriter(ITEMS_FILE)) {
	                for (String line : lines) {
	                    writer.write(line + System.lineSeparator());
	                }
	            }
	            logTransaction(Integer.parseInt(itemId), "Item Removed", 0, 0, "REMOVE");
	            JOptionPane.showMessageDialog(null, "Item removed successfully.");
	        } else {
	            JOptionPane.showMessageDialog(null, "Item not found!");
	        }
	    }

	    // Method to view the daily transaction report
	    private static void viewTransactionReport() {
	        StringBuilder report = new StringBuilder();
	        try (BufferedReader reader = new BufferedReader(new FileReader(TRANSACTIONS_FILE))) {
	            String line;
	            while ((line = reader.readLine()) != null) {
	                report.append(line).append("\n");
	            }
	        } catch (IOException e) {
	            JOptionPane.showMessageDialog(null, "Error reading transactions file.");
	        }
	        JOptionPane.showMessageDialog(null, report.toString(), "Daily Transaction Report", JOptionPane.INFORMATION_MESSAGE);
	    }

	    // Method to generate a new unique item ID
	    private static int generateNewId() throws IOException {
	        int maxId = 0;
	        try (BufferedReader reader = new BufferedReader(new FileReader(ITEMS_FILE))) {
	            String line;
	            while ((line = reader.readLine()) != null) {
	                String[] parts = line.split(",");
	                int id = Integer.parseInt(parts[0]);
	                if (id > maxId) {
	                    maxId = id;
	                }
	            }
	        }
	        return maxId + 1; // Return the next available ID
	    }

	    // Method to log a transaction in the transactions file
	    private static void logTransaction(int id, String description, int qty, double totalPrice, String action) throws IOException {
	        try (FileWriter writer = new FileWriter(TRANSACTIONS_FILE, true)) {
	            writer.write(String.format("%05d,%s,%d,%.2f,%s%n", id, description, qty, totalPrice, action));
	        }
	    }
	}
